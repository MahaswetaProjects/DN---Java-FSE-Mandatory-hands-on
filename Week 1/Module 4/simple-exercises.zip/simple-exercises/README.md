# Exercise Solutions — 6 Folders

One folder per PDF (folders "1" and "2" cover the two Mockito sheets,
which were both numbered "3" in your filenames). Each folder is a
completely standalone Maven project — no shared code, no nested
packages, just `pom.xml` + `src/main/java` + `src/test/java`.

| Folder | Covers |
|---|---|
| `1-junit-basic` | JUnit Basic Testing Exercises (Ex1–4) — uses JUnit 4, exactly as that PDF's dependency snippet shows |
| `2-junit-advanced` | Advanced JUnit Testing Exercises (Ex1–5) — uses JUnit 5, since that PDF's annotations (`@ParameterizedTest`, `@TestMethodOrder`) are JUnit 5 only |
| `3-mockito` | Mockito Exercises + Mockito Advanced Exercises (Ex1–7 and Ex1–5) |
| `4-spring-test` | JUnit Spring Test Exercises (Ex1–9) |
| `5-mockito-spring` | Mockito Mock Dependencies Exercises (Ex1–3) |
| `6-slf4j-logging` | SLF4J Logging Exercises (Ex1–3) |

To run any folder: `cd <folder> && mvn test` (folder 6 has no tests —
run its `main()` classes directly instead).

**One change from the PDFs worth knowing:** in folders 4 and 5,
`UserService.getUserById()` throws an exception instead of returning
`null` (the PDF shows `.orElse(null)`), so the "missing user" and "404
handling" exercises actually have something real to test.

**One limitation:** my sandbox can't reach Maven Central, so I couldn't
run `mvn test` myself to confirm everything passes. Run it yourself as
the first step — if anything fails, send me the error and I'll fix it.
