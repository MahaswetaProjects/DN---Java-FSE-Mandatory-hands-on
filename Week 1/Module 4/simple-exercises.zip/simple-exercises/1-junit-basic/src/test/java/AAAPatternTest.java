import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

// Exercise 4: Arrange-Act-Assert pattern, test fixtures, setup/teardown
public class AAAPatternTest {

    private Calculator calculator;

    @Before
    public void setUp() {
        // runs before every test - fresh fixture each time
        calculator = new Calculator();
    }

    @After
    public void tearDown() {
        // runs after every test - cleanup
        calculator = null;
    }

    @Test
    public void testAdd_usingAAA() {
        // Arrange
        int a = 10;
        int b = 15;

        // Act
        int result = calculator.add(a, b);

        // Assert
        assertEquals(25, result);
    }

    @Test
    public void testSubtract_usingAAA() {
        // Arrange
        int a = 10;
        int b = 4;

        // Act
        int result = calculator.subtract(a, b);

        // Assert
        assertEquals(6, result);
    }
}
