import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Needed so @SpringBootTest / @WebMvcTest / @DataJpaTest have a
// configuration class to bootstrap the application context from.
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
