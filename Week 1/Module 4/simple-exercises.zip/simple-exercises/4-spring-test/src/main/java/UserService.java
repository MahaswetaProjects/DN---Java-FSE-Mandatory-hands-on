import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.NoSuchElementException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // NOTE: the PDF shows ".orElse(null)" here. We use ".orElseThrow(...)"
    // instead, so that Exercise 6 (service exception handling) and
    // Exercise 8 (404 via @ControllerAdvice) have an actual exception to
    // test - returning null would make both exercises untestable.
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }
}
