import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.assertEquals;

// Exercise 1: Basic Unit Test for a Service Method
// Exercise 9: Parameterized Test with JUnit
public class CalculatorServiceTest {

    @Test
    public void testAdd() {
        CalculatorService calculatorService = new CalculatorService();
        assertEquals(5, calculatorService.add(2, 3));
    }

    @ParameterizedTest
    @CsvSource({
            "2, 3, 5",
            "0, 0, 0",
            "-1, 1, 0",
            "10, -5, 5"
    })
    public void testAdd_withVariousInputs(int a, int b, int expectedSum) {
        CalculatorService calculatorService = new CalculatorService();
        assertEquals(expectedSum, calculatorService.add(a, b));
    }
}
