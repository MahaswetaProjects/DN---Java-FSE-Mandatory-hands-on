import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Exercise 4: Exception Testing
public class ExceptionThrowerTest {

    private ExceptionThrower exceptionThrower = new ExceptionThrower();

    @Test
    public void testThrowException_withNegativeValue() {
        assertThrows(IllegalArgumentException.class, () -> exceptionThrower.throwException(-1));
    }

    @Test
    public void testThrowException_withPositiveValue_doesNotThrow() {
        assertDoesNotThrow(() -> exceptionThrower.throwException(5));
    }
}
