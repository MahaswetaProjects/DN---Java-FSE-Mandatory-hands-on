import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import java.time.Duration;
import static org.junit.jupiter.api.Assertions.assertTimeout;

// Exercise 5: Timeout and Performance Testing
public class PerformanceTesterTest {

    private PerformanceTester performanceTester = new PerformanceTester();

    @Test
    public void testPerformTask_completesWithinOneSecond() {
        assertTimeout(Duration.ofSeconds(1), performanceTester::performTask);
    }

    @Test
    @Timeout(1) // fails automatically if it takes longer than 1 second
    public void testPerformTask_withTimeoutAnnotation() {
        performanceTester.performTask();
    }
}
