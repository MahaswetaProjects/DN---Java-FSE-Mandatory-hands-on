import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import static org.junit.jupiter.api.Assertions.*;

// Exercise 3: Test Execution Order
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class OrderedTests {

    private static StringBuilder executionOrder = new StringBuilder();

    @Test
    @Order(1)
    public void firstTest() {
        executionOrder.append("1");
        assertTrue(true);
    }

    @Test
    @Order(2)
    public void secondTest() {
        executionOrder.append("2");
        assertTrue(true);
    }

    @Test
    @Order(3)
    public void thirdTest_confirmsOrder() {
        executionOrder.append("3");
        assertEquals("123", executionOrder.toString());
    }
}
