// Exercise 4: a class with a method that throws an exception.
public class ExceptionThrower {
    public void throwException(int value) {
        if (value < 0) {
            throw new IllegalArgumentException("Value must not be negative: " + value);
        }
    }
}
