// Exercise 5: a class with a method that should complete quickly.
public class PerformanceTester {
    public void performTask() {
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
