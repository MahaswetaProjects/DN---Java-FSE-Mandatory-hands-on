// Exercise 1: a class that checks if a number is even.
public class EvenChecker {
    public boolean isEven(int number) {
        return number % 2 == 0;
    }
}
