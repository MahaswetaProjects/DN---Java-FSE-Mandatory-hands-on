import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Exercise 2: Parameterized Logging
public class ParameterizedLoggingExample {
    private static final Logger logger = LoggerFactory.getLogger(ParameterizedLoggingExample.class);

    public static void main(String[] args) {
        String user = "Alice";
        int loginCount = 3;

        // SLF4J only builds the message string if the level is enabled -
        // avoids wasted concatenation work when, say, debug is off.
        logger.info("User {} logged in", user);
        logger.info("User {} has logged in {} times today", user, loginCount);
    }
}
