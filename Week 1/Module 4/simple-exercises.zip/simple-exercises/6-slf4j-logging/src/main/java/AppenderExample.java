import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Exercise 3: Using Different Appenders
// logback.xml routes everything at "debug" level and above to BOTH the
// console appender and the "app.log" file appender.
public class AppenderExample {
    private static final Logger logger = LoggerFactory.getLogger(AppenderExample.class);

    public static void main(String[] args) {
        logger.debug("Debug: starting appender demonstration");
        logger.info("Info: application is running normally");
        logger.warn("Warning: this is a non-critical issue");
        logger.error("Error: something went wrong");
    }
}
