import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

// Exercise 1: Mocking a Service Dependency in a Controller Test.
// Plain Mockito, no Spring context at all - we call the controller
// method directly. @InjectMocks uses reflection to set the
// @Autowired private field, even with no setter.
@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @Test
    public void testGetUser() {
        User user = new User("Alice");
        user.setId(1L);
        when(userService.getUserById(1L)).thenReturn(user);

        ResponseEntity<User> response = userController.getUser(1L);

        assertEquals(200, response.getStatusCode().value());
        assertEquals("Alice", response.getBody().getName());
    }
}
