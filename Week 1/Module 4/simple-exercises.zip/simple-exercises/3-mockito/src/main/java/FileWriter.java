// Doc 4, Exercise 3.
public interface FileWriter {
    void write(String content);
}
