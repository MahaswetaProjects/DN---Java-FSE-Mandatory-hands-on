// Doc 4, Exercise 2: Mocking External Services (RESTful APIs).
public interface RestClient {
    String getResponse();
}
