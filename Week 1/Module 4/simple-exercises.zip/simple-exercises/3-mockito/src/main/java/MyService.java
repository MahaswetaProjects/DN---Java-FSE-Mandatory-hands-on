// Doc 3: the service under test for all 7 Mockito basic exercises.
public class MyService {
    private final ExternalApi externalApi;

    public MyService(ExternalApi externalApi) {
        this.externalApi = externalApi;
    }

    public String fetchData() {
        return externalApi.getData();
    }

    public void logActivity(String message) {
        externalApi.sendData(message);
    }

    public String performSequence() {
        externalApi.connect();
        String data = externalApi.getData();
        externalApi.disconnect();
        return data;
    }
}
