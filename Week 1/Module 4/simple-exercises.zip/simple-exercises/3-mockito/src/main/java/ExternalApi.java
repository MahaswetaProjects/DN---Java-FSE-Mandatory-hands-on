// Doc 3: an external API the service below depends on.
public interface ExternalApi {
    String getData();
    void sendData(String data);
    void connect();
    void disconnect();
}
