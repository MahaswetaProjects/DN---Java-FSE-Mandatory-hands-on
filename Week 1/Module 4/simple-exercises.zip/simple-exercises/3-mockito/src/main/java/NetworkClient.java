// Doc 4, Exercise 4: Mocking Network Interactions.
public interface NetworkClient {
    String connect();
}
