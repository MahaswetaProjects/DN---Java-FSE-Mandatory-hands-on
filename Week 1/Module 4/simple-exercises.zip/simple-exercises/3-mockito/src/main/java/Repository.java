// Doc 4, Exercise 1: Mocking Databases and Repositories.
public interface Repository {
    String getData();
}
