// Doc 4, Exercise 3: Mocking File I/O.
public interface FileReader {
    String read();
}
